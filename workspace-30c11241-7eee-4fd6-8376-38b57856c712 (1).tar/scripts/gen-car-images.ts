import ZAI from 'z-ai-web-dev-sdk'
import fs from 'fs'
import path from 'path'

const OUT_DIR = '/home/z/my-project/public/cars'

const BASE_STYLE =
  'professional automotive studio photography, three-quarter front view, whole car visible, centered composition, parked on glossy black reflective floor, dark charcoal studio backdrop, warm champagne-gold rim lighting, soft golden ambient glow, subtle floor reflection, cinematic luxury car advertisement, photorealistic, ultra detailed, high quality, no text, no watermark, blank license plate'

const ITEMS: { file: string; size: string; subject: string }[] = [
  {
    file: 'sceptre.png',
    size: '1344x768',
    subject:
      'luxury flagship sedan, long elegant proportions, champagne gold metallic paint, sleek chrome grille, slim LED headlights, flush door handles',
  },
  {
    file: 'vanta-s.png',
    size: '1344x768',
    subject:
      'sporty executive sedan, aggressive athletic stance, graphite grey metallic paint, blacked-out grille, sharp LED headlights, subtle rear spoiler',
  },
  {
    file: 'meridian.png',
    size: '1344x768',
    subject:
      'full-size luxury SUV, commanding upright presence, obsidian black paint, large chrome vertical-slat grille, muscular boxy wheel arches, roof rails',
  },
  {
    file: 'terra.png',
    size: '1344x768',
    subject:
      'compact luxury SUV, modern coupe-like sloping roofline, bronze copper metallic paint, sporty body cladding, sleek LED headlights',
  },
  {
    file: 'ion.png',
    size: '1344x768',
    subject:
      'sleek electric fastback sedan, aerodynamic smooth body, pearl white paint, full-width connected LED light bar, flush door handles, closed-off grille',
  },
  {
    file: 'volt-x.png',
    size: '1344x768',
    subject:
      'modern electric luxury SUV, dark emerald green metallic paint, full-width LED light bar, aerodynamic alloy wheels, coupe-SUV silhouette',
  },
  {
    file: 'apex-gt.png',
    size: '1344x768',
    subject:
      'elegant grand tourer coupe, long hood short deck proportions, deep burgundy red metallic paint, warm gold-tinted alloy wheels, muscular rear haunches',
  },
  {
    file: 'strada-r.png',
    size: '1344x768',
    subject:
      'open-top luxury two-seater roadster convertible with the roof down, liquid silver metallic paint, low raked windscreen, sculpted aerodynamic body',
  },
  {
    file: 'hero.png',
    size: '1440x720',
    subject:
      'cinematic wide banner photograph of a dark luxury sedan on a glossy black showroom stage, dramatic champagne-gold light streaks, atmospheric haze, dark moody background with golden bokeh lights, ultra luxury automotive presentation',
  },
]

function buildPrompt(subject: string) {
  return `${subject}, ${BASE_STYLE}`
}

async function generateOne(
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  item: { file: string; size: string; subject: string }
) {
  const outPath = path.join(OUT_DIR, item.file)
  if (fs.existsSync(outPath) && fs.statSync(outPath).size > 20000) {
    console.log(`SKIP (exists) ${item.file}`)
    return true
  }
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await zai.images.generations.create({
        prompt: buildPrompt(item.subject),
        size: item.size,
      })
      const base64 = response?.data?.[0]?.base64
      if (!base64) throw new Error('empty base64 in response')
      const buffer = Buffer.from(base64, 'base64')
      if (buffer.length < 20000) throw new Error(`suspiciously small image (${buffer.length} bytes)`)
      fs.writeFileSync(outPath, buffer)
      console.log(`OK ${item.file} (${(buffer.length / 1024).toFixed(0)} KB)`)
      return true
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      console.error(`ATTEMPT ${attempt}/3 FAILED ${item.file}: ${message}`)
      if (attempt < 3) await new Promise((r) => setTimeout(r, 1500 * attempt))
    }
  }
  return false
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true })
  const zai = await ZAI.create()
  let failed = 0
  for (const item of ITEMS) {
    const ok = await generateOne(zai, item)
    if (!ok) failed++
  }
  console.log(`DONE. failed=${failed}`)
  if (failed > 0) process.exit(1)
}

main().catch((error) => {
  console.error('FATAL', error)
  process.exit(1)
})
