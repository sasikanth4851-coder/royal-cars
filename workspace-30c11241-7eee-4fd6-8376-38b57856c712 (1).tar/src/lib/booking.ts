export interface BookingDetails {
  name: string
  phoneMasked: string
  carName: string
  dateLabel: string
  timeSlot: string
  showroom: string
}

export interface BookingState {
  status: 'idle' | 'success' | 'error'
  message?: string
  reference?: string
  details?: BookingDetails
  errors?: Record<string, string>
}

export const initialBookingState: BookingState = { status: 'idle' }
