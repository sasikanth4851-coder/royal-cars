'use client'

import { useState } from 'react'
import { Navbar } from '@/components/showroom/navbar'
import { Hero } from '@/components/showroom/hero'
import { Fleet } from '@/components/showroom/fleet'
import { Compare } from '@/components/showroom/compare'
import { TestDrive } from '@/components/showroom/test-drive'
import { Footer } from '@/components/showroom/footer'

export default function Home() {
  const [compareIds, setCompareIds] = useState<string[]>(['sceptre', 'ion'])
  const [testDriveCarId, setTestDriveCarId] = useState('sceptre')

  function toggleCompare(id: string) {
    setCompareIds((prev) =>
      prev.includes(id) ? prev.filter((entry) => entry !== id) : [...prev, id]
    )
  }

  function bookCar(id: string) {
    setTestDriveCarId(id)
    document.getElementById('test-drive')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#0a0a0b] text-zinc-100 selection:bg-gold-500/30 selection:text-gold-100">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Fleet compareIds={compareIds} onToggleCompare={toggleCompare} onBook={bookCar} />
        <Compare compareIds={compareIds} onToggleCompare={toggleCompare} />
        <TestDrive preselectedId={testDriveCarId} />
      </main>
      <Footer />
    </div>
  )
}
