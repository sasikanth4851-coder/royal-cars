'use server'

import { z } from 'zod'
import { db } from '@/lib/db'
import { CARS, SHOWROOMS, TIME_SLOTS } from '@/data/cars'
import type { BookingState } from '@/lib/booking'

const bookingSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, 'Please enter your full name')
    .max(60, 'Name is too long'),
  phone: z
    .string()
    .trim()
    .regex(/^[6-9]\d{9}$/, 'Enter a valid 10-digit Indian mobile number'),
  email: z
    .string()
    .trim()
    .regex(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Enter a valid email address')
    .or(z.literal('')),
  carId: z.string().min(1, 'Please choose a model'),
  date: z.string().min(1, 'Please pick a preferred date'),
  timeSlot: z
    .string()
    .min(1, 'Please choose a time slot')
    .refine((v) => TIME_SLOTS.includes(v), 'Please choose a valid time slot'),
  showroom: z
    .string()
    .min(1, 'Please choose a showroom')
    .refine((v) => SHOWROOMS.includes(v), 'Please choose a valid showroom'),
})

function makeReference(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let out = ''
  for (let i = 0; i < 6; i++) {
    out += chars[Math.floor(Math.random() * chars.length)]
  }
  return `AM-${out}`
}

export async function bookTestDrive(
  _prev: BookingState,
  formData: FormData
): Promise<BookingState> {
  const raw = {
    name: String(formData.get('name') ?? ''),
    phone: String(formData.get('phone') ?? ''),
    email: String(formData.get('email') ?? ''),
    carId: String(formData.get('carId') ?? ''),
    date: String(formData.get('date') ?? ''),
    timeSlot: String(formData.get('timeSlot') ?? ''),
    showroom: String(formData.get('showroom') ?? ''),
  }

  const parsed = bookingSchema.safeParse(raw)
  if (!parsed.success) {
    const errors: Record<string, string> = {}
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? 'form')
      if (!errors[key]) errors[key] = issue.message
    }
    return {
      status: 'error',
      message: 'Please review the highlighted fields and try again.',
      errors,
    }
  }

  const data = parsed.data
  const car = CARS.find((c) => c.id === data.carId)
  if (!car) {
    return { status: 'error', message: 'Unknown model selected.', errors: { carId: 'Please choose a model from the fleet' } }
  }

  const today = new Date()
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(
    today.getDate()
  ).padStart(2, '0')}`
  if (data.date < todayStr) {
    return {
      status: 'error',
      message: 'Please review the highlighted fields and try again.',
      errors: { date: 'Please pick a date from today onwards' },
    }
  }

  const reference = makeReference()

  try {
    await db.testDriveBooking.create({
      data: {
        reference,
        name: data.name,
        phone: data.phone,
        email: data.email === '' ? null : data.email,
        carId: car.id,
        carName: car.fullName,
        date: data.date,
        timeSlot: data.timeSlot,
        showroom: data.showroom,
      },
    })
  } catch {
    return {
      status: 'error',
      message: 'We could not save your booking. Please try again in a moment.',
    }
  }

  return {
    status: 'success',
    reference,
    message: `Your ${car.fullName} test drive is confirmed.`,
    details: {
      name: data.name,
      phoneMasked: `${data.phone.slice(0, 3)}••••${data.phone.slice(7)}`,
      carName: car.fullName,
      dateLabel: new Date(`${data.date}T00:00:00`).toLocaleDateString('en-IN', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }),
      timeSlot: data.timeSlot,
      showroom: data.showroom,
    },
  }
}
