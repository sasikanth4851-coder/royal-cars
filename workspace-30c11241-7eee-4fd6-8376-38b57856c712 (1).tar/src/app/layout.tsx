import type { Metadata } from "next";
import { Geist, Geist_Mono, Playfair_Display } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  style: ["normal", "italic"],
});

export const metadata: Metadata = {
  title: "Aurelia Motors — Luxury Car Showroom",
  description:
    "Explore the Aurelia Motors collection: eight signature models spanning luxury sedans, SUVs, electric fastbacks and grand tourers. Compare specifications, prices and features, then book a test drive.",
  keywords: ["Aurelia Motors", "luxury cars", "car showroom", "test drive", "compare cars", "electric vehicles"],
  icons: {
    icon: "/aurelia-logo.svg",
  },
  openGraph: {
    title: "Aurelia Motors — Luxury Car Showroom",
    description:
      "Eight signature models. One emblem. Compare, explore and book a test drive.",
    siteName: "Aurelia Motors",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${playfair.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
