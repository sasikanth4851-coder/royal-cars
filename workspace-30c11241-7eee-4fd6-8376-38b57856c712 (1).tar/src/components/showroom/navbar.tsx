'use client'

import { useState } from 'react'
import { Menu, X } from 'lucide-react'
import { Logo } from './logo'

const LINKS = [
  { href: '#fleet', label: 'The Fleet' },
  { href: '#compare', label: 'Compare' },
  { href: '#test-drive', label: 'Test Drive' },
]

export function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-[#0a0a0b]/85 backdrop-blur-md">
      <nav
        className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6"
        aria-label="Main navigation"
      >
        <a href="#top" className="flex items-center gap-3" aria-label="Aurelia Motors — back to top">
          <Logo size={30} />
          <span className="flex flex-col leading-none">
            <span className="font-display text-lg font-semibold tracking-[0.25em] text-gold-300">
              AURELIA
            </span>
            <span className="mt-1 text-[9px] tracking-[0.5em] text-zinc-400">MOTORS</span>
          </span>
        </a>

        <div className="hidden items-center gap-8 md:flex">
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm text-zinc-300 transition-colors hover:text-gold-300"
            >
              {link.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <a
            href="#test-drive"
            className="hidden min-h-[44px] items-center rounded-full bg-gold-500 px-5 text-sm font-semibold text-[#171510] transition-colors hover:bg-gold-400 sm:inline-flex"
          >
            Book a Test Drive
          </a>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/15 text-zinc-200 transition-colors hover:border-gold-500/50 hover:text-gold-300 md:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="border-t border-white/10 bg-[#0c0c0e] px-4 pb-4 pt-2 md:hidden">
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="block rounded-lg px-3 py-3 text-sm text-zinc-200 transition-colors hover:bg-white/5 hover:text-gold-300"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#test-drive"
            onClick={() => setOpen(false)}
            className="mt-2 flex min-h-[44px] items-center justify-center rounded-full bg-gold-500 px-4 text-sm font-semibold text-[#171510]"
          >
            Book a Test Drive
          </a>
        </div>
      )}
    </header>
  )
}
