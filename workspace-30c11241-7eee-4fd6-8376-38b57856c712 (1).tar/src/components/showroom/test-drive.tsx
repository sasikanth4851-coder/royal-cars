'use client'

import { useActionState, useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  CalendarCheck,
  CheckCircle2,
  Loader2,
  MapPin,
  Phone,
  Route,
  User,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { bookTestDrive } from '@/app/actions'
import { initialBookingState } from '@/lib/booking'
import { CARS, SHOWROOMS, TIME_SLOTS } from '@/data/cars'

const EXPECTATIONS = [
  {
    icon: Route,
    title: 'A curated route',
    text: 'Fifteen to twenty kilometres across city streets and an open highway stretch.',
  },
  {
    icon: User,
    title: 'A product expert on board',
    text: 'No sales script — just answers, spec deep-dives and honest advice.',
  },
  {
    icon: CalendarCheck,
    title: 'Zero commitment',
    text: 'Reschedule or cancel any time, free of charge, up to two hours before your slot.',
  },
]

function FieldError({ message }: { message?: string }) {
  if (!message) return null
  return <p className="mt-1.5 text-xs text-red-400">{message}</p>
}

function BookingExperience({
  preselectedId,
  onReset,
}: {
  preselectedId: string
  onReset: () => void
}) {
  const [state, formAction, isPending] = useActionState(bookTestDrive, initialBookingState)
  const [carId, setCarId] = useState(preselectedId)
  const [showroom, setShowroom] = useState(SHOWROOMS[0])
  const [timeSlot, setTimeSlot] = useState('')
  const [today, setToday] = useState<string | undefined>(undefined)

  useEffect(() => {
    setCarId(preselectedId)
  }, [preselectedId])

  useEffect(() => {
    const now = new Date()
    setToday(
      `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
        now.getDate()
      ).padStart(2, '0')}`
    )
  }, [])

  if (state.status === 'success') {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.97 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className="rounded-2xl border border-gold-500/40 bg-card p-8 text-center sm:p-10"
      >
        <CheckCircle2 className="mx-auto h-14 w-14 text-gold-400" aria-hidden="true" />
        <h3 className="mt-5 font-display text-3xl font-medium text-zinc-50">
          Booking confirmed
        </h3>
        <p className="mt-2 text-sm text-zinc-400">{state.message}</p>
        <p className="mt-6 inline-block rounded-xl border border-gold-500/40 bg-gold-500/10 px-6 py-3 font-mono text-2xl tracking-[0.2em] text-gold-300">
          {state.reference}
        </p>
        <p className="mt-3 text-xs uppercase tracking-[0.2em] text-zinc-500">
          Your booking reference
        </p>
        <dl className="mx-auto mt-8 max-w-sm space-y-3 rounded-xl border border-white/10 bg-white/[0.02] p-5 text-left text-sm">
          <div className="flex justify-between gap-4">
            <dt className="text-zinc-500">Guest</dt>
            <dd className="text-right font-medium text-zinc-100">{state.details?.name}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-zinc-500">Mobile</dt>
            <dd className="font-medium text-zinc-100">{state.details?.phoneMasked}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-zinc-500">Model</dt>
            <dd className="text-right font-medium text-zinc-100">{state.details?.carName}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-zinc-500">Slot</dt>
            <dd className="text-right font-medium text-zinc-100">
              {state.details?.dateLabel} · {state.details?.timeSlot}
            </dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-zinc-500">Showroom</dt>
            <dd className="text-right font-medium text-zinc-100">{state.details?.showroom}</dd>
          </div>
        </dl>
        <p className="mt-6 text-sm leading-relaxed text-zinc-400">
          Our concierge will call you within two hours to confirm your route and pickup. Keep
          your reference handy — quote it at the showroom desk.
        </p>
        <Button
          onClick={onReset}
          variant="outline"
          className="mt-8 min-h-[48px] rounded-full border-gold-500/50 px-8 text-gold-300 hover:bg-gold-500/10 hover:text-gold-200"
        >
          Book another drive
        </Button>
      </motion.div>
    )
  }

  return (
    <form
      action={formAction}
      className="rounded-2xl border border-white/10 bg-card p-6 sm:p-8"
      noValidate={false}
    >
      <input type="hidden" name="carId" value={carId} />
      <input type="hidden" name="timeSlot" value={timeSlot} />
      <input type="hidden" name="showroom" value={showroom} />

      <div className="grid gap-5 sm:grid-cols-2">
        <div className="sm:col-span-1">
          <Label htmlFor="td-name" className="text-sm text-zinc-300">
            Full name
          </Label>
          <Input
            id="td-name"
            name="name"
            placeholder="Aarav Sharma"
            autoComplete="name"
            required
            className="mt-2 min-h-[48px] bg-white/[0.04]"
          />
          <FieldError message={state.errors?.name} />
        </div>

        <div className="sm:col-span-1">
          <Label htmlFor="td-phone" className="text-sm text-zinc-300">
            Mobile number
          </Label>
          <Input
            id="td-phone"
            name="phone"
            type="tel"
            inputMode="numeric"
            maxLength={10}
            placeholder="98765 43210"
            autoComplete="tel"
            required
            className="mt-2 min-h-[48px] bg-white/[0.04]"
          />
          <FieldError message={state.errors?.phone} />
        </div>

        <div className="sm:col-span-2">
          <Label htmlFor="td-email" className="text-sm text-zinc-300">
            Email <span className="text-zinc-500">(optional)</span>
          </Label>
          <Input
            id="td-email"
            name="email"
            type="email"
            placeholder="you@example.com"
            autoComplete="email"
            className="mt-2 min-h-[48px] bg-white/[0.04]"
          />
          <FieldError message={state.errors?.email} />
        </div>

        <div className="sm:col-span-2">
          <Label htmlFor="td-car" className="text-sm text-zinc-300">
            Model
          </Label>
          <Select value={carId} onValueChange={setCarId}>
            <SelectTrigger
              id="td-car"
              aria-label="Select model"
              className="mt-2 min-h-[48px] w-full bg-white/[0.04] data-[placeholder]:text-zinc-400"
            >
              <SelectValue placeholder="Choose your Aurelia" />
            </SelectTrigger>
            <SelectContent>
              {CARS.map((car) => (
                <SelectItem key={car.id} value={car.id}>
                  {car.fullName} — {car.category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FieldError message={state.errors?.carId} />
        </div>

        <div className="sm:col-span-1">
          <Label htmlFor="td-date" className="text-sm text-zinc-300">
            Preferred date
          </Label>
          <Input
            id="td-date"
            name="date"
            type="date"
            min={today}
            required
            className="mt-2 min-h-[48px] bg-white/[0.04]"
          />
          <FieldError message={state.errors?.date} />
        </div>

        <div className="sm:col-span-1">
          <p className="text-sm text-zinc-300">Preferred time</p>
          <div className="mt-2 grid grid-cols-2 gap-2" role="group" aria-label="Preferred time slot">
            {TIME_SLOTS.map((slot) => (
              <button
                key={slot}
                type="button"
                onClick={() => setTimeSlot(slot)}
                aria-pressed={timeSlot === slot}
                className={`min-h-[48px] rounded-lg border text-sm transition-colors ${
                  timeSlot === slot
                    ? 'border-gold-500 bg-gold-500 font-semibold text-[#171510]'
                    : 'border-white/15 bg-white/[0.03] text-zinc-300 hover:border-gold-500/50 hover:text-gold-300'
                }`}
              >
                {slot}
              </button>
            ))}
          </div>
          <FieldError message={state.errors?.timeSlot} />
        </div>

        <div className="sm:col-span-2">
          <Label htmlFor="td-showroom" className="text-sm text-zinc-300">
            Showroom
          </Label>
          <Select value={showroom} onValueChange={setShowroom}>
            <SelectTrigger
              id="td-showroom"
              aria-label="Select showroom"
              className="mt-2 min-h-[48px] w-full bg-white/[0.04] data-[placeholder]:text-zinc-400"
            >
              <SelectValue placeholder="Choose a showroom" />
            </SelectTrigger>
            <SelectContent>
              {SHOWROOMS.map((room) => (
                <SelectItem key={room} value={room}>
                  {room}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FieldError message={state.errors?.showroom} />
        </div>
      </div>

      {state.status === 'error' && state.message && !state.errors && (
        <p className="mt-5 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
          {state.message}
        </p>
      )}

      <Button
        type="submit"
        disabled={isPending}
        className="mt-7 flex min-h-[52px] w-full items-center justify-center rounded-full bg-gold-500 text-sm font-semibold text-[#171510] transition-colors hover:bg-gold-400 disabled:opacity-60"
      >
        {isPending ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
            Confirming your drive…
          </>
        ) : (
          'Confirm Test Drive'
        )}
      </Button>
      <p className="mt-3 text-center text-xs text-zinc-500">
        No payment needed. Our concierge confirms every booking by phone.
      </p>
    </form>
  )
}

export function TestDrive({ preselectedId }: { preselectedId: string }) {
  const [formKey, setFormKey] = useState(0)

  return (
    <section
      id="test-drive"
      className="scroll-mt-24 border-t border-white/5 py-20 sm:py-24"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="text-center"
        >
          <p className="text-xs font-medium uppercase tracking-[0.4em] text-gold-400">
            Test Drive
          </p>
          <h2 className="mt-4 font-display text-4xl font-medium text-zinc-50 sm:text-5xl">
            Feel it before you <span className="italic text-gold-300">own it.</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-zinc-400">
            Book a drive at any Aurelia signature showroom. Choose your model, slot and city —
            we take care of the rest.
          </p>
        </motion.div>

        <div className="mt-12 grid gap-8 lg:grid-cols-[1fr_1.4fr]">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, delay: 0.1, ease: 'easeOut' }}
            className="flex flex-col gap-4"
          >
            {EXPECTATIONS.map((item) => (
              <div
                key={item.title}
                className="rounded-2xl border border-white/10 bg-white/[0.02] p-5"
              >
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-500/15">
                    <item.icon className="h-5 w-5 text-gold-400" aria-hidden="true" />
                  </span>
                  <h3 className="font-display text-lg text-zinc-100">{item.title}</h3>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-zinc-400">{item.text}</p>
              </div>
            ))}

            <div className="rounded-2xl border border-gold-500/30 bg-gold-500/[0.06] p-5">
              <p className="flex items-center gap-2 text-sm font-medium text-gold-300">
                <MapPin className="h-4 w-4" aria-hidden="true" />
                Five signature showrooms across India
              </p>
              <p className="mt-2 text-sm leading-relaxed text-zinc-400">
                Mumbai · New Delhi · Bengaluru · Hyderabad · Pune
              </p>
              <p className="mt-4 flex items-center gap-2 text-sm text-zinc-300">
                <Phone className="h-4 w-4 text-gold-400" aria-hidden="true" />
                Concierge: 1800 266 0000, 9 AM – 9 PM daily
              </p>
            </div>
          </motion.div>

          <BookingExperience
            key={formKey}
            preselectedId={preselectedId}
            onReset={() => setFormKey((k) => k + 1)}
          />
        </div>
      </div>
    </section>
  )
}
