export function Logo({ size = 32 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      aria-hidden="true"
      className="shrink-0"
    >
      <circle cx="32" cy="32" r="29" stroke="#d9b96c" strokeWidth="2" />
      <path
        d="M32 15 L45.5 47 M32 15 L18.5 47"
        stroke="#d9b96c"
        strokeWidth="3.2"
        strokeLinecap="round"
      />
      <path
        d="M25 36.5 L39 36.5"
        stroke="#d9b96c"
        strokeWidth="2.4"
        strokeLinecap="round"
      />
    </svg>
  )
}
