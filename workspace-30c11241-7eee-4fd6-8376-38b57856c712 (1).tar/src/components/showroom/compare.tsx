'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { GitCompare, X } from 'lucide-react'
import { CARS, formatPrice, type Car } from '@/data/cars'

interface CompareProps {
  compareIds: string[]
  onToggleCompare: (id: string) => void
}

interface Row {
  label: string
  render: (car: Car) => string
  value?: (car: Car) => number | null
  best?: 'high' | 'low'
}

function buildRows(anyEv: boolean, anyIce: boolean): Row[] {
  const rows: Row[] = [
    { label: 'Ex-showroom price', render: (c) => formatPrice(c.priceLakh), best: 'low', value: (c) => c.priceLakh },
    { label: 'Power', render: (c) => `${c.specs.powerPs} PS`, best: 'high', value: (c) => c.specs.powerPs },
    { label: 'Torque', render: (c) => `${c.specs.torqueNm} Nm`, best: 'high', value: (c) => c.specs.torqueNm },
    { label: '0–100 km/h', render: (c) => `${c.specs.zeroToHundred.toFixed(1)} s`, best: 'low', value: (c) => c.specs.zeroToHundred },
    { label: 'Top speed', render: (c) => `${c.specs.topSpeedKmh} km/h`, best: 'high', value: (c) => c.specs.topSpeedKmh },
    { label: 'Engine / motor', render: (c) => c.specs.engine },
    { label: 'Transmission', render: (c) => c.specs.transmission },
    { label: 'Drivetrain', render: (c) => c.specs.drivetrain },
    { label: 'Seats', render: (c) => String(c.specs.seats) },
  ]
  if (anyIce) {
    rows.push({
      label: 'Economy',
      render: (c) => (c.specs.economyKmpl !== null ? `${c.specs.economyKmpl} km/l` : '—'),
      best: 'high',
      value: (c) => c.specs.economyKmpl,
    })
  }
  if (anyEv) {
    rows.push({
      label: 'EV range',
      render: (c) => (c.specs.rangeKm !== null ? `${c.specs.rangeKm} km` : '—'),
      best: 'high',
      value: (c) => c.specs.rangeKm,
    })
    rows.push({ label: 'DC fast charging', render: (c) => c.specs.charging ?? '—' })
  }
  rows.push({ label: 'Fuel', render: (c) => c.fuel })
  return rows
}

export function Compare({ compareIds, onToggleCompare }: CompareProps) {
  const selected = CARS.filter((car) => compareIds.includes(car.id))
  const anyEv = selected.some((car) => car.specs.rangeKm !== null)
  const anyIce = selected.some((car) => car.specs.economyKmpl !== null)
  const rows = buildRows(anyEv, anyIce)

  function winnerIds(row: Row): string[] {
    if (!row.best || !row.value || selected.length < 2) return []
    const values = selected
      .map((car) => ({ id: car.id, v: row.value!(car) }))
      .filter((entry): entry is { id: string; v: number } => entry.v !== null)
    if (values.length < 2) return []
    const best =
      row.best === 'high'
        ? Math.max(...values.map((entry) => entry.v))
        : Math.min(...values.map((entry) => entry.v))
    const winners = values.filter((entry) => entry.v === best).map((entry) => entry.id)
    return winners.length === values.length ? [] : winners
  }

  return (
    <section id="compare" className="scroll-mt-24 border-t border-white/5 bg-[#0c0c0e] py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="text-center"
        >
          <p className="text-xs font-medium uppercase tracking-[0.4em] text-gold-400">
            Side by Side
          </p>
          <h2 className="mt-4 font-display text-4xl font-medium text-zinc-50 sm:text-5xl">
            Compare <span className="italic text-gold-300">up to three.</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-zinc-400">
            Pick two or three models below — or tap Compare on any car card. Row winners are
            highlighted in gold.
          </p>
        </motion.div>

        <div
          className="luxe-scroll mt-12 flex gap-2 overflow-x-auto pb-2"
          role="group"
          aria-label="Select models to compare"
        >
          {CARS.map((car) => {
            const active = compareIds.includes(car.id)
            const disabled = !active && compareIds.length >= 3
            return (
              <button
                key={car.id}
                type="button"
                disabled={disabled}
                aria-pressed={active}
                onClick={() => onToggleCompare(car.id)}
                className={`inline-flex min-h-[44px] shrink-0 items-center gap-2 rounded-full border px-4 text-sm transition-colors ${
                  active
                    ? 'border-gold-500 bg-gold-500 font-semibold text-[#171510]'
                    : disabled
                      ? 'cursor-not-allowed border-white/10 bg-white/[0.02] text-zinc-600'
                      : 'border-white/15 bg-white/[0.03] text-zinc-300 hover:border-gold-500/50 hover:text-gold-300'
                }`}
              >
                {active && <X className="h-3.5 w-3.5" aria-hidden="true" />}
                {car.name}
              </button>
            )
          })}
        </div>

        {selected.length === 0 ? (
          <div className="mt-8 flex flex-col items-center rounded-2xl border border-dashed border-white/15 p-16 text-center">
            <GitCompare className="h-10 w-10 text-zinc-600" aria-hidden="true" />
            <p className="mt-4 font-display text-xl text-zinc-300">Nothing to compare yet</p>
            <p className="mt-2 max-w-md text-sm text-zinc-500">
              Select two or three models above to see their specifications, prices and features
              side by side.
            </p>
          </div>
        ) : (
          <div className="luxe-scroll mt-8 overflow-x-auto rounded-2xl border border-white/10 bg-card">
            <table className="w-full min-w-[640px] border-collapse text-left">
              <caption className="sr-only">
                Side-by-side specification comparison of selected Aurelia models
              </caption>
              <thead>
                <tr>
                  <th
                    scope="col"
                    className="w-44 border-b border-white/10 bg-white/[0.02] p-4 align-bottom text-[11px] font-medium uppercase tracking-[0.2em] text-zinc-500"
                  >
                    Specification
                  </th>
                  {selected.map((car) => (
                    <th
                      key={car.id}
                      scope="col"
                      className="min-w-[190px] border-b border-l border-white/10 bg-white/[0.02] p-4 align-bottom"
                    >
                      <div className="relative mb-3 h-20 w-full overflow-hidden rounded-xl">
                        <Image
                          src={car.image}
                          alt={`${car.fullName} studio render`}
                          fill
                          sizes="220px"
                          className="object-cover"
                        />
                      </div>
                      <div className="font-display text-lg font-medium text-zinc-100">
                        {car.fullName}
                      </div>
                      <div className="mt-0.5 text-sm text-gold-300">
                        {formatPrice(car.priceLakh)}
                      </div>
                      <button
                        type="button"
                        onClick={() => onToggleCompare(car.id)}
                        className="mt-2 inline-flex min-h-[36px] items-center gap-1 rounded-full border border-white/15 px-3 text-xs text-zinc-400 transition-colors hover:border-gold-500/50 hover:text-gold-300"
                      >
                        <X className="h-3 w-3" aria-hidden="true" />
                        Remove
                      </button>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => {
                  const winners = winnerIds(row)
                  return (
                    <tr key={row.label} className="align-middle">
                      <th
                        scope="row"
                        className="border-b border-white/5 p-4 text-[11px] font-medium uppercase tracking-[0.15em] text-zinc-500"
                      >
                        {row.label}
                      </th>
                      {selected.map((car) => {
                        const isWinner = winners.includes(car.id)
                        return (
                          <td
                            key={car.id}
                            className="border-b border-l border-white/5 p-4 text-sm text-zinc-200"
                          >
                            <span className={isWinner ? 'font-semibold text-gold-300' : undefined}>
                              {row.render(car)}
                            </span>
                            {isWinner && (
                              <span className="ml-2 rounded-full bg-gold-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-gold-400">
                                Best
                              </span>
                            )}
                          </td>
                        )
                      })}
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  )
}
