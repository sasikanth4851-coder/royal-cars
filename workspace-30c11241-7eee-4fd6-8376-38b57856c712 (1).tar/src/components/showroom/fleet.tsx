'use client'

import { useMemo, useState } from 'react'
import Image from 'next/image'
import { motion } from 'framer-motion'
import { Car as CarIcon, Check, ChevronDown, Fuel, GitCompare, Leaf, RotateCcw, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { useToast } from '@/hooks/use-toast'
import { CARS, economyLabel, formatPrice, type BodyType, type Car, type FuelType } from '@/data/cars'

type BodyFilter = 'All' | BodyType
type FuelFilter = 'All' | FuelType

const BODY_OPTIONS: BodyFilter[] = ['All', 'Sedan', 'SUV', 'Sports']
const FUEL_OPTIONS: FuelFilter[] = ['All', 'Petrol', 'Hybrid', 'Electric']
const PRICE_MIN = 30
const PRICE_MAX = 240

const FUEL_ICONS: Record<FuelType, React.ComponentType<{ className?: string }>> = {
  Petrol: Fuel,
  Hybrid: Leaf,
  Electric: Zap,
}

interface FleetProps {
  compareIds: string[]
  onToggleCompare: (id: string) => void
  onBook: (id: string) => void
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`inline-flex min-h-[44px] items-center gap-1.5 rounded-full border px-4 text-sm transition-colors ${
        active
          ? 'border-gold-500 bg-gold-500 font-semibold text-[#171510]'
          : 'border-white/15 bg-white/[0.03] text-zinc-300 hover:border-gold-500/50 hover:text-gold-300'
      }`}
    >
      {children}
    </button>
  )
}

function CarCard({
  car,
  compared,
  onToggleCompare,
  onBook,
}: {
  car: Car
  compared: boolean
  onToggleCompare: (id: string) => void
  onBook: (id: string) => void
}) {
  const [showFeatures, setShowFeatures] = useState(false)
  const FuelIcon = FUEL_ICONS[car.fuel]

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-card transition-colors hover:border-gold-500/40">
      <div className="relative aspect-[16/10] overflow-hidden">
        <Image
          src={car.image}
          alt={`${car.fullName} — ${car.category} studio render`}
          fill
          sizes="(max-width: 768px) 100vw, (max-width: 1280px) 50vw, 33vw"
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <span className="absolute left-3 top-3 rounded-full bg-black/70 px-3 py-1 text-[11px] font-medium uppercase tracking-wider text-gold-300 backdrop-blur">
          {car.category}
        </span>
        <span className="absolute right-3 top-3 inline-flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1 text-[11px] font-medium text-zinc-200 backdrop-blur">
          <FuelIcon className="h-3 w-3 text-gold-300" aria-hidden="true" />
          {car.fuel}
        </span>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="font-display text-2xl font-medium text-zinc-100">{car.name}</h3>
            <p className="mt-1 text-sm text-zinc-400">{car.tagline}</p>
          </div>
          <div className="shrink-0 text-right">
            <p className="font-semibold text-gold-300">{formatPrice(car.priceLakh)}</p>
            <p className="mt-0.5 text-[10px] uppercase tracking-wider text-zinc-500">
              Ex-showroom
            </p>
          </div>
        </div>

        <dl className="mt-5 grid grid-cols-3 gap-2 rounded-xl border border-white/10 bg-white/[0.02] p-3 text-center">
          <div>
            <dt className="text-[10px] uppercase tracking-wider text-zinc-500">Power</dt>
            <dd className="mt-0.5 text-sm font-medium text-zinc-100">{car.specs.powerPs} PS</dd>
          </div>
          <div>
            <dt className="text-[10px] uppercase tracking-wider text-zinc-500">0–100</dt>
            <dd className="mt-0.5 text-sm font-medium text-zinc-100">
              {car.specs.zeroToHundred.toFixed(1)} s
            </dd>
          </div>
          <div>
            <dt className="text-[10px] uppercase tracking-wider text-zinc-500">
              {car.specs.rangeKm !== null ? 'Range' : 'Economy'}
            </dt>
            <dd className="mt-0.5 text-sm font-medium text-zinc-100">{economyLabel(car)}</dd>
          </div>
        </dl>

        <button
          type="button"
          onClick={() => setShowFeatures((v) => !v)}
          aria-expanded={showFeatures}
          className="mt-4 flex min-h-[44px] w-full items-center justify-between rounded-lg px-1 text-sm text-zinc-300 transition-colors hover:text-gold-300"
        >
          <span>Features &amp; details</span>
          <ChevronDown
            className={`h-4 w-4 transition-transform ${showFeatures ? 'rotate-180' : ''}`}
            aria-hidden="true"
          />
        </button>

        {showFeatures && (
          <div className="mb-2 rounded-xl border border-white/10 bg-white/[0.02] p-4">
            <p className="text-sm leading-relaxed text-zinc-400">{car.description}</p>
            <p className="mt-3 text-xs text-zinc-500">
              <span className="text-zinc-300">{car.specs.engine}</span> · {car.specs.transmission} ·{' '}
              {car.specs.drivetrain}
            </p>
            <ul className="mt-3 grid grid-cols-1 gap-1.5 sm:grid-cols-2">
              {car.features.map((feature) => (
                <li key={feature} className="flex items-start gap-2 text-sm text-zinc-300">
                  <Check
                    className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gold-400"
                    aria-hidden="true"
                  />
                  {feature}
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="mt-auto flex gap-2 pt-4">
          <Button
            variant="outline"
            onClick={() => onBook(car.id)}
            className="min-h-[44px] flex-1 rounded-full border-gold-500/50 text-gold-300 hover:bg-gold-500/10 hover:text-gold-200"
          >
            Book Test Drive
          </Button>
          <Button
            variant="secondary"
            aria-pressed={compared}
            onClick={() => onToggleCompare(car.id)}
            className={
              compared
                ? 'min-h-[44px] flex-1 rounded-full border border-gold-500 bg-gold-500/15 text-gold-300 hover:bg-gold-500/25'
                : 'min-h-[44px] flex-1 rounded-full border border-white/15 bg-white/[0.03] text-zinc-300 hover:border-gold-500/50 hover:text-gold-300'
            }
          >
            <GitCompare className="mr-1.5 h-4 w-4" aria-hidden="true" />
            {compared ? 'In Compare' : 'Compare'}
          </Button>
        </div>
      </div>
    </article>
  )
}

export function Fleet({ compareIds, onToggleCompare, onBook }: FleetProps) {
  const [body, setBody] = useState<BodyFilter>('All')
  const [fuel, setFuel] = useState<FuelFilter>('All')
  const [maxPrice, setMaxPrice] = useState(PRICE_MAX)
  const { toast } = useToast()

  const filtered = useMemo(
    () =>
      CARS.filter(
        (car) =>
          (body === 'All' || car.body === body) &&
          (fuel === 'All' || car.fuel === fuel) &&
          car.priceLakh <= maxPrice
      ),
    [body, fuel, maxPrice]
  )

  const hasActiveFilters = body !== 'All' || fuel !== 'All' || maxPrice < PRICE_MAX

  function handleToggleCompare(id: string) {
    if (!compareIds.includes(id) && compareIds.length >= 3) {
      toast({
        title: 'Comparison is full',
        description: 'You can compare up to three models. Remove one to add another.',
      })
      return
    }
    onToggleCompare(id)
  }

  function resetFilters() {
    setBody('All')
    setFuel('All')
    setMaxPrice(PRICE_MAX)
  }

  return (
    <section id="fleet" className="scroll-mt-24 py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="text-center"
        >
          <p className="text-xs font-medium uppercase tracking-[0.4em] text-gold-400">
            The Collection
          </p>
          <h2 className="mt-4 font-display text-4xl font-medium text-zinc-50 sm:text-5xl">
            Eight signatures. <span className="italic text-gold-300">One emblem.</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-zinc-400">
            Filter the collection by body style, fuel and budget — then flip any car open to see
            its full specification and feature sheet.
          </p>
        </motion.div>

        <div className="mt-12 flex flex-col gap-6 rounded-2xl border border-white/10 bg-white/[0.02] p-4 sm:p-6">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            <div className="flex flex-col gap-5">
              <div>
                <p className="mb-2 text-[11px] font-medium uppercase tracking-[0.2em] text-zinc-500">
                  Body type
                </p>
                <div className="flex flex-wrap gap-2">
                  {BODY_OPTIONS.map((option) => (
                    <Chip
                      key={option}
                      active={body === option}
                      onClick={() => setBody(option)}
                    >
                      {option}
                    </Chip>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-2 text-[11px] font-medium uppercase tracking-[0.2em] text-zinc-500">
                  Fuel
                </p>
                <div className="flex flex-wrap gap-2">
                  {FUEL_OPTIONS.map((option) => (
                    <Chip
                      key={option}
                      active={fuel === option}
                      onClick={() => setFuel(option)}
                    >
                      {option !== 'All' &&
                        (() => {
                          const Icon = FUEL_ICONS[option as FuelType]
                          return <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                        })()}
                      {option}
                    </Chip>
                  ))}
                </div>
              </div>
            </div>

            <div className="w-full max-w-md lg:pt-1">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-zinc-500">
                  Maximum budget
                </p>
                <p className="text-sm font-semibold text-gold-300">
                  {maxPrice >= PRICE_MAX ? 'Any price' : `Up to ${formatPrice(maxPrice)}`}
                </p>
              </div>
              <Slider
                min={PRICE_MIN}
                max={PRICE_MAX}
                step={5}
                value={[maxPrice]}
                onValueChange={(value) => setMaxPrice(value[0] ?? PRICE_MAX)}
                aria-label="Maximum budget in lakh rupees"
                className="mt-4"
              />
              <p className="mt-3 text-sm text-zinc-400">
                Showing{' '}
                <span className="font-semibold text-zinc-100">{filtered.length}</span> of{' '}
                {CARS.length} models
              </p>
            </div>
          </div>

          {hasActiveFilters && (
            <Button
              variant="ghost"
              onClick={resetFilters}
              className="min-h-[44px] self-start rounded-full text-zinc-300 hover:bg-white/5 hover:text-gold-300"
            >
              <RotateCcw className="mr-2 h-4 w-4" aria-hidden="true" />
              Reset filters
            </Button>
          )}
        </div>

        {filtered.length === 0 ? (
          <div className="mt-12 flex flex-col items-center rounded-2xl border border-dashed border-white/15 p-16 text-center">
            <CarIcon className="h-10 w-10 text-zinc-600" aria-hidden="true" />
            <p className="mt-4 font-display text-xl text-zinc-300">
              No models match these filters
            </p>
            <p className="mt-2 text-sm text-zinc-500">
              Try widening the budget or choosing a different body style.
            </p>
            <Button
              variant="outline"
              onClick={resetFilters}
              className="mt-6 min-h-[44px] rounded-full border-gold-500/50 text-gold-300 hover:bg-gold-500/10 hover:text-gold-200"
            >
              Reset filters
            </Button>
          </div>
        ) : (
          <div className="mt-12 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((car) => (
              <CarCard
                key={car.id}
                car={car}
                compared={compareIds.includes(car.id)}
                onToggleCompare={handleToggleCompare}
                onBook={onBook}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
