import { Logo } from './logo'
import { SHOWROOMS } from '@/data/cars'

const EXPLORE_LINKS = [
  { href: '#fleet', label: 'The Fleet' },
  { href: '#compare', label: 'Compare Models' },
  { href: '#test-drive', label: 'Book a Test Drive' },
]

export function Footer() {
  return (
    <footer className="mt-auto border-t border-white/10 bg-[#0c0c0e] pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            <Logo size={28} />
            <span className="font-display text-lg font-semibold tracking-[0.25em] text-gold-300">
              AURELIA
            </span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-zinc-400">
            Eight signature models, one emblem. Crafted for those who measure journeys in
            moments, not miles.
          </p>
        </div>

        <nav aria-label="Footer navigation">
          <h3 className="text-xs font-semibold uppercase tracking-[0.25em] text-zinc-500">
            Explore
          </h3>
          <ul className="mt-4 space-y-3 text-sm text-zinc-300">
            {EXPLORE_LINKS.map((link) => (
              <li key={link.href}>
                <a href={link.href} className="transition-colors hover:text-gold-300">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.25em] text-zinc-500">
            Showrooms
          </h3>
          <ul className="mt-4 space-y-3 text-sm text-zinc-400">
            {SHOWROOMS.map((showroom) => (
              <li key={showroom}>{showroom}</li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.25em] text-zinc-500">
            Concierge
          </h3>
          <p className="mt-4 text-sm leading-relaxed text-zinc-400">
            1800 266 0000 (toll-free)
            <br />
            Daily, 9:00 AM – 9:00 PM
          </p>
          <p className="mt-3 text-sm text-zinc-400">concierge@aureliamotors.example</p>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-zinc-500 sm:flex-row sm:px-6">
          <p>© 2026 Aurelia Motors Pvt. Ltd. All rights reserved.</p>
          <p>A concept showcase — Aurelia Motors is a fictional marque.</p>
        </div>
      </div>
    </footer>
  )
}
