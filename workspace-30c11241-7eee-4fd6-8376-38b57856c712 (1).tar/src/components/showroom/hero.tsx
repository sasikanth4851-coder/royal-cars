'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'

const STATS = [
  { value: '8', label: 'Signature models' },
  { value: '620 km', label: 'Maximum EV range' },
  { value: '3.6 s', label: 'Quickest 0–100 km/h' },
  { value: '5', label: 'Signature showrooms' },
]

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
}

export function Hero() {
  return (
    <section id="top" className="relative flex min-h-[92vh] flex-col overflow-hidden">
      <Image
        src="/cars/hero.png"
        alt="Aurelia signature showroom at night — spotlights over the model collection on a polished dark floor"
        fill
        priority
        sizes="100vw"
        className="object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0b]/85 via-[#0a0a0b]/45 to-[#0a0a0b]" />

      <div className="relative mx-auto flex w-full max-w-7xl flex-1 flex-col items-center justify-center px-4 pb-16 pt-28 text-center sm:px-6">
        <motion.p
          {...fadeUp}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="text-xs font-medium uppercase tracking-[0.4em] text-gold-400"
        >
          The MMXXVI Collection
        </motion.p>
        <motion.h1
          {...fadeUp}
          transition={{ duration: 0.7, delay: 0.1, ease: 'easeOut' }}
          className="mt-5 font-display text-5xl font-medium leading-tight text-zinc-50 sm:text-6xl lg:text-7xl"
        >
          Arrive <span className="italic text-gold-300">unforgettably.</span>
        </motion.h1>
        <motion.p
          {...fadeUp}
          transition={{ duration: 0.7, delay: 0.2, ease: 'easeOut' }}
          className="mt-6 max-w-2xl text-base leading-relaxed text-zinc-300 sm:text-lg"
        >
          Eight signature models — luxury sedans, commanding SUVs, silent electric fastbacks and
          long-legged grand tourers — each carrying the Aurelia emblem and a showroom waiting to
          hand you the keys.
        </motion.p>
        <motion.div
          {...fadeUp}
          transition={{ duration: 0.7, delay: 0.3, ease: 'easeOut' }}
          className="mt-10 flex flex-col gap-3 sm:flex-row"
        >
          <a
            href="#fleet"
            className="flex min-h-[48px] items-center justify-center rounded-full bg-gold-500 px-8 text-sm font-semibold text-[#171510] transition-colors hover:bg-gold-400"
          >
            Explore the Fleet
          </a>
          <a
            href="#test-drive"
            className="flex min-h-[48px] items-center justify-center rounded-full border border-gold-500/60 px-8 text-sm font-semibold text-gold-300 transition-colors hover:bg-gold-500/10"
          >
            Book a Test Drive
          </a>
        </motion.div>
      </div>

      <div className="relative border-t border-white/10 bg-[#0a0a0b]/60 backdrop-blur-sm">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-4 py-8 sm:px-6 lg:grid-cols-4">
          {STATS.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="font-display text-3xl text-gold-300">{stat.value}</p>
              <p className="mt-1 text-[11px] uppercase tracking-[0.2em] text-zinc-400">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
