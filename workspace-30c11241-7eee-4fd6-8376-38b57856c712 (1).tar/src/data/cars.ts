export type BodyType = 'Sedan' | 'SUV' | 'Sports'
export type FuelType = 'Petrol' | 'Hybrid' | 'Electric'

export interface CarSpecs {
  engine: string
  powerPs: number
  torqueNm: number
  zeroToHundred: number
  topSpeedKmh: number
  transmission: string
  drivetrain: string
  seats: number
  rangeKm: number | null
  economyKmpl: number | null
  charging: string | null
}

export interface Car {
  id: string
  name: string
  fullName: string
  category: string
  body: BodyType
  fuel: FuelType
  tagline: string
  description: string
  priceLakh: number
  image: string
  specs: CarSpecs
  features: string[]
}

export const CARS: Car[] = [
  {
    id: 'sceptre',
    name: 'Sceptre',
    fullName: 'Aurelia Sceptre',
    category: 'Flagship Sedan',
    body: 'Sedan',
    fuel: 'Petrol',
    tagline: 'The definitive Aurelia statement.',
    description:
      'Our flagship sedan pairs a twin-turbo V6 with a lounge-grade cabin, tuned for boulevards as much as for motorways.',
    priceLakh: 102,
    image: '/cars/sceptre.png',
    specs: {
      engine: '3.0L V6 Twin-Turbo',
      powerPs: 410,
      torqueNm: 550,
      zeroToHundred: 4.7,
      topSpeedKmh: 290,
      transmission: '8-speed Automatic',
      drivetrain: 'AWD',
      seats: 5,
      rangeKm: null,
      economyKmpl: 9.8,
      charging: null,
    },
    features: [
      'Massaging Nappa leather seats',
      'Rear executive lounge package',
      'Adaptive air suspension',
      '19-speaker studio audio',
      'Panoramic glass roof',
      'Night vision assist',
      'Heads-up display',
      'Soft-close doors',
      '360° camera suite',
      'Quad-zone climate control',
    ],
  },
  {
    id: 'vanta-s',
    name: 'Vanta S',
    fullName: 'Aurelia Vanta S',
    category: 'Sports Sedan',
    body: 'Sedan',
    fuel: 'Petrol',
    tagline: 'Precision-bred executive athlete.',
    description:
      'A rear-driven sports sedan that sharpens every commute into a corner-exit, with a cabin that never raises its voice.',
    priceLakh: 64.5,
    image: '/cars/vanta-s.png',
    specs: {
      engine: '2.0L Inline-4 Turbo',
      powerPs: 280,
      torqueNm: 420,
      zeroToHundred: 5.6,
      topSpeedKmh: 250,
      transmission: '7-speed Dual-Clutch',
      drivetrain: 'RWD',
      seats: 5,
      rangeKm: null,
      economyKmpl: 12.4,
      charging: null,
    },
    features: [
      'Sport bucket seats',
      'Adaptive dampers',
      'Launch control',
      '12.3-inch curved cockpit',
      '16-speaker audio',
      'Ambient lighting, 64 colours',
      'Rev-match downshifting',
      'Carbon-fibre interior pack',
      'Wireless smartphone mirroring',
      'Level-2 driver assist',
    ],
  },
  {
    id: 'meridian',
    name: 'Meridian',
    fullName: 'Aurelia Meridian',
    category: 'Full-Size SUV',
    body: 'SUV',
    fuel: 'Hybrid',
    tagline: 'Command every road.',
    description:
      'Seven seats, one commanding silhouette — the full-size Aurelia for families who arrive prominently and travel quietly.',
    priceLakh: 185,
    image: '/cars/meridian.png',
    specs: {
      engine: '4.0L V8 + 48V Hybrid',
      powerPs: 530,
      torqueNm: 700,
      zeroToHundred: 4.9,
      topSpeedKmh: 285,
      transmission: '9-speed Automatic',
      drivetrain: 'AWD',
      seats: 7,
      rangeKm: null,
      economyKmpl: 11.2,
      charging: null,
    },
    features: [
      'Executive 2nd-row captain seats',
      'Rear entertainment screens',
      'Cooled seats in all three rows',
      'Active noise cancellation',
      'Air suspension with terrain modes',
      'Hands-free power tailgate',
      '22-inch forged alloy wheels',
      '3.5-tonne towing package',
      'Digital key with ultrawide band',
      'Tri-zone climate control',
    ],
  },
  {
    id: 'terra',
    name: 'Terra',
    fullName: 'Aurelia Terra',
    category: 'Compact SUV',
    body: 'SUV',
    fuel: 'Hybrid',
    tagline: 'The city-smart Aurelia.',
    description:
      'Compact dimensions, complete luxury. The everyday Aurelia with hybrid efficiency and a genuinely premium cabin.',
    priceLakh: 36.9,
    image: '/cars/terra.png',
    specs: {
      engine: '1.5L Turbo Mild-Hybrid',
      powerPs: 170,
      torqueNm: 300,
      zeroToHundred: 8.2,
      topSpeedKmh: 210,
      transmission: '7-speed Dual-Clutch',
      drivetrain: 'FWD',
      seats: 5,
      rangeKm: null,
      economyKmpl: 16.8,
      charging: null,
    },
    features: [
      '10.25-inch infotainment',
      'Wireless smartphone mirroring',
      'Level-2 ADAS suite',
      'Panoramic sunroof',
      'Ventilated front seats',
      '6 airbags',
      'Rear AC vents',
      'Adaptive cruise assist',
      'Connected-car telematics',
      'Cabin PM2.5 air purification',
    ],
  },
  {
    id: 'ion',
    name: 'Ion',
    fullName: 'Aurelia Ion',
    category: 'Electric Fastback',
    body: 'Sedan',
    fuel: 'Electric',
    tagline: 'Silence, electrified.',
    description:
      'An 800-volt fastback that charges faster than a coffee stop and glides through the city in near silence.',
    priceLakh: 82,
    image: '/cars/ion.png',
    specs: {
      engine: 'Dual-Motor Electric',
      powerPs: 460,
      torqueNm: 650,
      zeroToHundred: 4.3,
      topSpeedKmh: 250,
      transmission: 'Single-speed Direct Drive',
      drivetrain: 'AWD',
      seats: 5,
      rangeKm: 620,
      economyKmpl: null,
      charging: '10–80% · 28 min @ 150 kW',
    },
    features: [
      '800V performance architecture',
      'Full-width OLED light bar',
      'Glass panoramic roof',
      'Vegan luxury interior',
      'Vehicle-to-load power outlet',
      'Over-the-air updates',
      '19-inch aero wheels',
      'Heat-pump climate system',
      'Rear-wheel steering',
      'Driver attention assist',
    ],
  },
  {
    id: 'volt-x',
    name: 'Volt X',
    fullName: 'Aurelia Volt X',
    category: 'Electric SUV',
    body: 'SUV',
    fuel: 'Electric',
    tagline: 'The electric family flagship.',
    description:
      'Three rows of calm, 540 kilometres of range — the electric Aurelia built for school runs and long weekends alike.',
    priceLakh: 94.5,
    image: '/cars/volt-x.png',
    specs: {
      engine: 'Dual-Motor Electric',
      powerPs: 420,
      torqueNm: 620,
      zeroToHundred: 5.1,
      topSpeedKmh: 220,
      transmission: 'Single-speed Direct Drive',
      drivetrain: 'AWD',
      seats: 7,
      rangeKm: 540,
      economyKmpl: null,
      charging: '10–80% · 32 min @ 150 kW',
    },
    features: [
      'Three rows, seven seats',
      'Fold-flat second and third rows',
      '15.6-inch centre display',
      '360° camera with see-through view',
      'Vehicle-to-load power outlet',
      'Massaging driver seat',
      'Cabin air purification',
      'Panoramic glass roof',
      'Hands-free tailgate',
      'Over-the-air updates',
    ],
  },
  {
    id: 'apex-gt',
    name: 'Apex GT',
    fullName: 'Aurelia Apex GT',
    category: 'Grand Tourer',
    body: 'Sports',
    fuel: 'Petrol',
    tagline: 'Continental pace, couture comfort.',
    description:
      'A 585 PS grand tourer built to cross continents between breakfast and dinner, with luggage cut to fit its boot.',
    priceLakh: 235,
    image: '/cars/apex-gt.png',
    specs: {
      engine: '4.0L V8 Bi-Turbo',
      powerPs: 585,
      torqueNm: 720,
      zeroToHundred: 3.6,
      topSpeedKmh: 320,
      transmission: '8-speed Dual-Clutch',
      drivetrain: 'RWD',
      seats: 4,
      rangeKm: null,
      economyKmpl: 8.9,
      charging: null,
    },
    features: [
      'Carbon-ceramic brakes',
      'Rear-axle steering',
      '18-speaker concert audio',
      'Quilted leather GT cabin',
      'Magnetic ride control',
      'Lightweight aluminium architecture',
      'Bespoke four-piece luggage set',
      'Active aerodynamic rear wing',
      'Track-tuned GT drive modes',
      'Performance traction management',
    ],
  },
  {
    id: 'strada-r',
    name: 'Strada R',
    fullName: 'Aurelia Strada R',
    category: 'Roadster',
    body: 'Sports',
    fuel: 'Petrol',
    tagline: 'Open air, pure focus.',
    description:
      'Two seats, open sky and one sonorous inline-six — the purest Aurelia being built today.',
    priceLakh: 168,
    image: '/cars/strada-r.png',
    specs: {
      engine: '3.0L Inline-6 Turbo',
      powerPs: 385,
      torqueNm: 520,
      zeroToHundred: 4.4,
      topSpeedKmh: 285,
      transmission: '7-speed Dual-Clutch',
      drivetrain: 'RWD',
      seats: 2,
      rangeKm: null,
      economyKmpl: 10.5,
      charging: null,
    },
    features: [
      'Soft-top opens in 11 seconds',
      'Neck-level heating',
      'Roll-over protection system',
      'Alcantara-wrapped steering wheel',
      'Track telemetry with lap timing',
      'Launch control',
      'Staggered 19/20-inch wheels',
      'Valve-controlled sport exhaust',
      'Wind deflector',
      'Two-seat cockpit with roll hoops',
    ],
  },
]

export const SHOWROOMS = [
  'Mumbai — Bandra Kurla Complex',
  'New Delhi — Aerocity',
  'Bengaluru — MG Road',
  'Hyderabad — Banjara Hills',
  'Pune — Koregaon Park',
]

export const TIME_SLOTS = ['10:00 AM', '12:30 PM', '03:00 PM', '05:30 PM']

export function formatPrice(lakh: number): string {
  if (lakh >= 100) return `₹${(lakh / 100).toFixed(2)} Cr`
  return `₹${lakh.toFixed(2)} Lakh`
}

export function economyLabel(car: Car): string {
  if (car.specs.rangeKm !== null) return `${car.specs.rangeKm} km range`
  return `${car.specs.economyKmpl} km/l`
}
